import joblib, pandas as pd, streamlit as st

model = joblib.load("car_price_model.joblib")
st.title("Used Car Price Predictor")
st.caption("Prices in lakhs INR")

c1, c2 = st.columns(2)
brand = c1.text_input("Brand (first word of car name)", "swift").lower()
year = c2.number_input("Year", 2003, 2026, 2018)
present = c1.number_input("Price when new (lakhs)", 0.3, 100.0, 9.5)
kms = c2.number_input("Kms driven", 500, 500000, 30000, step=1000)
fuel = c1.selectbox("Fuel", ["Petrol", "Diesel", "CNG"])
trans = c2.selectbox("Transmission", ["Manual", "Automatic"])
seller = c1.selectbox("Seller type", ["Dealer", "Individual"])
owner = c2.selectbox("Previous owners", [0, 1, 2, 3])

if st.button("Predict"):
    age = 2026 - year
    row = pd.DataFrame([{"Present_Price": present, "Driven_kms": kms, "Owner": owner,
        "Car_Age": age, "Price_Drop_Ratio": kms / max(age, 1), "Fuel_Type": fuel,
        "Selling_type": seller, "Transmission": trans, "Brand": brand}])
    st.success(f"Estimated selling price: ₹{model.predict(row)[0]:.2f} lakhs")
