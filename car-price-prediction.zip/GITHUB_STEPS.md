# GitHub par upload karne ke steps

1. github.com par New repository banao: name `car-price-prediction`, Public, README tick MAT karo.
2. VS Code me is folder ko kholo (File > Open Folder), terminal kholo (Ctrl+`) aur chalao:

```bash
git init
git add .
git commit -m "Car price prediction project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/car-price-prediction.git
git push -u origin main
```
Login ke time password ki jagah Personal Access Token use karo
(GitHub > Settings > Developer settings > Tokens).

3. Baad me changes ke liye: `git add .` -> `git commit -m "msg"` -> `git push`
