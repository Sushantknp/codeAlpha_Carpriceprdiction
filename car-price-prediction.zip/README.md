# Car Price Prediction with Machine Learning

Predicts used-car selling prices (lakhs INR) using regression models built with Pandas, Scikit-learn and Matplotlib.

## Workflow
1. EDA (distributions, correlations, outliers)
2. Feature engineering: `Car_Age`, `Brand`, kms-per-year
3. Preprocessing: one-hot encoding, log-transform of skewed features, scaling, log-transformed target
4. Models: Ridge Regression, Random Forest, Gradient Boosting (5-fold CV)
5. Hyperparameter tuning with GridSearchCV
6. Evaluation: R2, MAE, RMSE, residuals, permutation importance

## Results
| Metric | Value |
|---|---|
| CV R2 (tuned Ridge Regression) | 0.96 |
| Test R2 | 0.91 |
| Test MAE | 0.82 lakhs |

![Evaluation](images/evaluation.png)

![Importance](images/importance.png)

## Real-world applications
Used-car marketplaces, dealer trade-in quotes, loan collateral valuation, insurance valuation.

## Limitations
Only ~300 rows, no horsepower/engine data, rare luxury cars poorly predicted.

## Run it
```bash
pip install -r requirements.txt
jupyter notebook notebooks/car_price.ipynb
streamlit run app.py
```
